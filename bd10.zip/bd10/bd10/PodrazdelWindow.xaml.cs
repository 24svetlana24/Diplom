﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для PodrazdelWindow.xaml
    /// </summary>
    public partial class PodrazdelWindow : Window
    {
        bd10Entities1 Add { get; set; }
        public PodrazdelWindow()
        {
            InitializeComponent();
            Loader();
        }
        public void Loader()
        {
            Add = new bd10Entities1();
            Podrazdel.ItemsSource = Add.Podrazdel.ToList();
        }
        private void qeq(object sender, RoutedEventArgs e) /*Кнопка  Удаления*/
        {
            Add = new bd10Entities1();
            Podrazdel item = Podrazdel.SelectedItem as Podrazdel;
            try
            {
                Podrazdel ser = Add.Podrazdel.Where(c => c.id == item.id).Single();
                Add.Podrazdel.Remove(ser);
                Add.SaveChanges();

                MessageBox.Show("Данные успешно удалены");
                refreshdatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void refreshdatagrid() /*обновление таблицы*/
        {
            Add = new bd10Entities1();
            Podrazdel.ItemsSource = Add.Podrazdel.ToList();
            Podrazdel.Items.Refresh();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 f1 = new Window1();
            f1.Show();
            Close();
        }

        // Нажатие кнопки добавления подраздления
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddPodrazdel podrazdelWindow = new AddPodrazdel();
            podrazdelWindow.Owner = this;
            podrazdelWindow.Show();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e) //Сохранить изменения
        {
            Podrazdel podrazdel = new Podrazdel();
            podrazdel = Podrazdel.SelectedItem as Podrazdel;

            podrazdel.name = a1.Text;
            podrazdel.sostav = a2.Text;
           
            MessageBox.Show("ИБП успешно добавлен в базу!");
            Add.SaveChanges();
            Podrazdel.ItemsSource = Add.Podrazdel.ToList();

            
        }
    }
    
}
