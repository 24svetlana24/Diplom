﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bd10Entities1 bd10;
        public MainWindow()
        {
            InitializeComponent();
            bd10 = new bd10Entities1();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var userAuth = bd10.Users.FirstOrDefault(x => x.Login == Login.Text && x.Password == Password.Password);
                if (userAuth == null)
                {
                    MessageBox.Show("Неверный логин или пароль попробуйте снова", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    switch (userAuth.Role)
                    {
                        case 1:
                            MessageBox.Show("С Возвращением!" + " " + userAuth.FIO);
                            MainWindow mainWindow = new MainWindow();
                            mainWindow.Show();
                            Close();

                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex.Message.ToString());
            }
            Window1 f1 = new Window1();
            f1.Show();
            Close();

        }
    }
}
    

